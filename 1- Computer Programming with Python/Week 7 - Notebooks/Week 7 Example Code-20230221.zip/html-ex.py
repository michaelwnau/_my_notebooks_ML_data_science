from bs4 import BeautifulSoup

def parse_index():
    with open(r"C:\Users\user\Downloads\index.html") as fp:
        soup = BeautifulSoup(fp, 'html.parser')
    print(soup.title.text)
    data = soup.find_all("li","grain")
    for item in data: print(item.text)
    return

parse_index()
