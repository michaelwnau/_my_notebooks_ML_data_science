import csv, pickle

infile = "C:/Users/user/Downloads/NCEL-Cash5.csv"
storage = "C:/Users/user/Downloads/data.pkl"

class Winner:
    def __init__(self, date, ball1, ball2, ball3, ball4, ball5, dp):
        self.date = date
        self.ball1 = int(ball1)
        self.ball2 = int(ball2)
        self.ball3 = int(ball3)
        self.ball4 = int(ball4)
        self.ball5 = int(ball5)
        self.doubleplay = bool(int(dp))
        
    def __str__(self):
        return f'Winning entry on {self.date} = {self.ball1},{self.ball2},{self.ball3},{self.ball4},{self.ball5} - DoublePlay is {self.doubleplay}'
        
with open(infile, "r") as fp:
    csv = csv.reader(fp)
    data = []
    headers = fp.readline()
    for line in csv:
        if len(line) > 1:
            data.append(Winner(*line))
        
print(len(data))
print(f'{data[1]}')

# pickle our data
with open(storage, "wb") as fp:
    pickle.dump(data, fp)

# unpickle our data
with open(storage, "rb") as fp:
    bb = pickle.load(fp)
    
print(len(bb))
print(f'{bb[5801]}')
  
